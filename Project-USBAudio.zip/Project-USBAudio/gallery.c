#include <stdio.h>
#include "Blinky.h"
#include "LPC17xx.h"                       
#include "GLCD.h"
#include "LED.h"
//#include "Board_ADC.h" 
#include "KBD.h"
#include "cat1.c"
#include "cat2.c"
#include "notcat.c"

#define __FI        1                      /* Font index 16x24               */
#define __USE_LCD   0										/* Uncomment to use the LCD */

//ITM Stimulus Port definitions for printf //////////////////
#define ITM_Port8(n)    (*((volatile unsigned char *)(0xE0000000+4*n)))
#define ITM_Port16(n)   (*((volatile unsigned short*)(0xE0000000+4*n)))
#define ITM_Port32(n)   (*((volatile unsigned long *)(0xE0000000+4*n)))

#define DEMCR           (*((volatile unsigned long *)(0xE000EDFC)))
#define TRCENA          0x01000000


uint32_t input;
int galleryOption = 0;

void gallerySelect(){
	switch(galleryOption){
		case 0:
			GLCD_Bitmap(0,20, 320, 216, CAT1_PIXEL_DATA);
		break;
		case 1:
			GLCD_Bitmap(0,20, 320, 216, CAT2_PIXEL_DATA);
		break;
		case 2:
			GLCD_Bitmap(0,20, 320, 216, NOTCAT_PIXEL_DATA);
		break;
	}
}

void gallery(){
		int i;
		GLCD_Clear(White);
		GLCD_SetBackColor(Blue);
		GLCD_SetTextColor(Yellow);
		GLCD_DisplayString(0, 0, __FI, "      Gallery:      ");
	
	  while (1) {                                /* Loop forever                  */
		//get Joystick input
		input = get_button();
		//sprintf(text, "0x%4X", input);
		//if there is a non zero joystick input
		if(input!=0){
				//assign output based on input
				switch(input){
					case KBD_SELECT:
						//does nothing
					break;
					
					case KBD_UP:
						if(galleryOption == 0){
							galleryOption = 3;
							gallerySelect();
						}
						else{
							galleryOption--;
							gallerySelect();
						}

					break;
					
					case KBD_LEFT:
						GLCD_Clear(White);
						return;
					break;
					
					case KBD_DOWN:
						if(galleryOption == 3){
							galleryOption = 0;
							gallerySelect();
						}
						else{
							galleryOption++;
							gallerySelect();
						}
					break;
					
					case KBD_RIGHT:
						//does nothing
					break;
				}
		}
		//busy-wait loop to reduce joystick sensitivity
		for(i = 0; i <1000000; i++){
			
		}
  }
}