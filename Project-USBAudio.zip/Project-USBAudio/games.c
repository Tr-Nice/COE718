#include <stdio.h>
#include "Blinky.h"
#include "LPC17xx.h"                       
#include "GLCD.h"
#include "LED.h"
//#include "Board_ADC.h" 
#include "KBD.h"

#define __FI        1                      /* Font index 16x24               */
#define __USE_LCD   0										/* Uncomment to use the LCD */

//ITM Stimulus Port definitions for printf //////////////////
#define ITM_Port8(n)    (*((volatile unsigned char *)(0xE0000000+4*n)))
#define ITM_Port16(n)   (*((volatile unsigned short*)(0xE0000000+4*n)))
#define ITM_Port32(n)   (*((volatile unsigned long *)(0xE0000000+4*n)))

#define DEMCR           (*((volatile unsigned long *)(0xE000EDFC)))
#define TRCENA          0x01000000

int goption;
uint32_t Ginput;

void gameSelect(){
	#ifdef  __USE_LCD						
		GLCD_SetBackColor(Blue);
		GLCD_SetTextColor(Yellow);
		GLCD_DisplayString(0, 0, __FI, "     Game Center     ");
		GLCD_SetTextColor(White);
		GLCD_SetBackColor(White);
		GLCD_SetTextColor(Blue);
		GLCD_DisplayString(4, 0, __FI, "1. Maze Game  ");
		GLCD_DisplayString(5, 0, __FI, "2. COMING SOON");
	#endif
	switch(goption){
						case 1:
							#ifdef  __USE_LCD
								GLCD_SetBackColor(Blue);
								GLCD_SetTextColor(White);
								GLCD_DisplayString(4, 0, __FI, "1. Maze Game  ");
								GLCD_SetBackColor(White);
								GLCD_SetTextColor(Blue);
								GLCD_DisplayString(5, 0, __FI, "2. COMING SOON");
							#endif
						break;
						case 2:
							#ifdef  __USE_LCD
								GLCD_DisplayString(4, 0, __FI, "1. Maze Game  ");
								GLCD_SetBackColor(Blue);
								GLCD_SetTextColor(White);
								GLCD_DisplayString(5, 0, __FI, "2. COMING SOON");
							#endif						
						break;
					}
				}

extern void game1();				
				
void games(){
		int i;
		GLCD_Clear(White);
		goption = 1;
		gameSelect();
	
	  while (1) {                                /* Loop forever                  */
		//get Joystick input
		Ginput = get_button();
		//sprintf(text, "0x%4X", input);
		//if there is a non zero joystick input
		if(Ginput!=0){
				//assign output based on input
				switch(Ginput){
					case KBD_SELECT:
						//does nothing
					break;
					
					case KBD_UP:
						if(goption == 1){
							goption = 2;
							gameSelect();
						}
						else{
							goption--;
							gameSelect();
						}
					break;
					
					case KBD_LEFT:
						GLCD_Clear(White);
						return;
					break;
					
					case KBD_DOWN:
					if(goption == 2){
							goption = 1;
							gameSelect();
						}
						else{
							goption++;
							gameSelect();
						}
					break;
					
					case KBD_RIGHT:
						switch(goption){
						case 1:
							game1();
							goption = 1;
							gameSelect();
						break;
						case 2:
							//game2();
							goption = 2;
							gameSelect();
						break;
					}
					break;
				}
		}
		//busy-wait loop to reduce joystick sensitivity
		for(i = 0; i <1000000; i++){
			
		}
  }
}