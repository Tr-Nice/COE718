#include <stdio.h>
#include "Blinky.h"
#include "LPC17xx.h"                       
#include "GLCD.h"
#include "LED.h"
//#include "Board_ADC.h" 
#include "KBD.h"
#include <string.h>

#define __FI        1                      /* Font index 16x24               */
#define __USE_LCD   0										/* Uncomment to use the LCD */

//ITM Stimulus Port definitions for printf //////////////////
#define ITM_Port8(n)    (*((volatile unsigned char *)(0xE0000000+4*n)))
#define ITM_Port16(n)   (*((volatile unsigned short*)(0xE0000000+4*n)))
#define ITM_Port32(n)   (*((volatile unsigned long *)(0xE0000000+4*n)))

#define DEMCR           (*((volatile unsigned long *)(0xE000EDFC)))
#define TRCENA          0x01000000

uint32_t G1input;		
char gtext[3];

int maze[10][20] = {//0=open space, 1= maze wall, 2=maze finish
	{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
	{1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
	{1,0,1,0,1,0,1,1,1,1,0,1,1,1,1,1,1,1,0,1},
	{1,0,1,0,1,0,1,1,1,1,0,1,1,1,0,0,0,1,1,1},
	{1,0,0,0,1,0,0,0,0,0,0,0,1,1,0,1,0,1,0,1},
	{1,0,1,0,1,1,1,1,1,1,1,0,1,1,0,1,0,1,0,1},
	{1,0,1,0,0,1,0,0,0,1,1,0,0,0,0,0,0,1,0,1},
	{1,0,1,1,1,1,0,1,0,1,1,1,1,1,1,0,1,1,0,1},
	{1,0,0,0,0,0,0,1,0,0,0,0,0,0,1,0,0,0,2,1},
	{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}};
		
int playerPos[] = {1,1};//player position in the maze (y,x)
int playerPosNew[] = {1,1};

void drawMaze(){
	int i,j;
	for(i = 0; i <= 10; i++){
		for(j = 0; j<=20; j++){
			if(maze[i][j]==0){
				GLCD_SetBackColor(White);
				GLCD_DisplayString(i, j, __FI, " ");
			}
			if(maze[i][j]==1){
				GLCD_SetBackColor(LightGrey);
				GLCD_DisplayString(i, j, __FI, " ");
			}
			else if(maze[i][j]==2){
				GLCD_SetBackColor(Green);
				GLCD_DisplayString(i, j, __FI, " ");
			}
		}
	}
}

int victoryScreen(){
	int i;
	GLCD_Clear(Blue);
	GLCD_SetTextColor(Yellow);
	GLCD_DisplayString(3, 0, __FI, "      You Won!      ");
	GLCD_DisplayString(4, 0, __FI, "     Thank You      ");
	GLCD_DisplayString(5, 0, __FI, "    For Playing!    ");
	GLCD_DisplayString(9, 0, __FI, " Press Left To Exit ");
			while (1) {                                /* Loop forever                  */
		//get Joystick input
	
		G1input = get_button();
		//if there is a non zero joystick input
		if(G1input!=0){
				//assign output based on input
				switch(G1input){
					case KBD_LEFT:
						GLCD_Clear(White);
						return 1;
					break;
				}
		}

		//busy-wait loop to reduce joystick sensitivity
		for(i = 0; i <10000000; i++){
			
		}
  }
	
}

void printCords(){
	GLCD_SetBackColor(LightGrey);
	GLCD_SetTextColor(Red);//print current position
	sprintf(gtext,"%d", playerPos[0]);
	GLCD_DisplayString(0, 0, __FI, (unsigned char *)gtext);
	sprintf(gtext,"%d", playerPos[1]);
	GLCD_DisplayString(0, 3, __FI, (unsigned char *)gtext);
}

int drawPlayer(){
	GLCD_SetBackColor(White);//replace old position with white
	GLCD_DisplayString(playerPos[0], playerPos[1], __FI, " ");
	GLCD_SetBackColor(Red);//place red in the new player position
	GLCD_DisplayString(playerPosNew[0], playerPosNew[1], __FI, " ");
	playerPos[0] = playerPosNew[0];//update old player position to current position
	playerPos[1] = playerPosNew[1];
	if(maze[playerPos[0]][playerPos[1]]==2){
		if(victoryScreen()==1){
			return 1;
		}
		else{
			return 0;
		}
	}
	return 0;
}

int movePlayer(int q){
	switch(q){
		case 1://up
			if(maze[playerPos[0]-1][playerPos[1]]!=1){
				playerPosNew[0]--;
				if(drawPlayer()==1){
					return 1;
				}
				printCords();
			}
		break;
		case 2://left
			if(maze[playerPos[0]][playerPos[1]-1]!=1){
				playerPosNew[1]--;
				if(drawPlayer()==1){
					return 1;
				}
				printCords();
			}
		break;
		case 3://down
			if(maze[playerPos[0]+1][playerPos[1]]!=1){
				playerPosNew[0]++;
				if(drawPlayer()==1){
					return 1;
				}
				printCords();
			}
		break;
		case 4://right
			if(maze[playerPos[0]][playerPos[1]+1]!=1){
				playerPosNew[1]++;
				if(drawPlayer()==1){
					return 1;
				}
				printCords();
			}
			break;
	}
	return 0;
}
void game1(){
		int i;
		playerPos[0] = 1;
		playerPos[1] = 1;
		playerPosNew[0] = 1;
		playerPosNew[1] = 1;
	  drawMaze();
		printCords();
		drawPlayer();
	
		while (1) {                                /* Loop forever                  */
		//get Joystick input
	
		G1input = get_button();
		//if there is a non zero joystick input
		if(G1input!=0){
				//assign output based on input
				switch(G1input){
					case KBD_SELECT:
						GLCD_Clear(White);
						return;
					break;
					
					case KBD_UP:
						GLCD_SetBackColor(Red);//place red in the new player position
						GLCD_DisplayString(0, 19, __FI, " ");
						if(movePlayer(1)==1){
							return;
						}
					break;
					
					case KBD_LEFT:
						GLCD_SetBackColor(Blue);//place red in the new player position
						GLCD_DisplayString(0, 19, __FI, " ");
						if(movePlayer(2)==1){
							return;
						}
					
					break;
					
					case KBD_DOWN:
						GLCD_SetBackColor(Green);//place red in the new player position
						GLCD_DisplayString(0, 19, __FI, " ");
						if(movePlayer(3)==1){
							return;
						}
					break;
					
					case KBD_RIGHT:
						GLCD_SetBackColor(Yellow);//place red in the new player position
						GLCD_DisplayString(0, 19, __FI, " ");
						if(movePlayer(4)==1){
							return;
						}
					break;
				}
		}

		//busy-wait loop to reduce joystick sensitivity
		for(i = 0; i <10000000; i++){
			
		}
  }
}