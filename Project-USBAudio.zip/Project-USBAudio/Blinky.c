/*----------------------------------------------------------------------------
 * Name:    Blinky.c
 * Purpose: LED Flasher
 * Note(s): __USE_LCD   - enable Output on LCD, uncomment #define in code to use
 *  				for demo (NOT for analysis purposes)
 *----------------------------------------------------------------------------
 * Copyright (c) 2008-2011 Keil - An ARM Company.
 * Name: Anita Tino
 *----------------------------------------------------------------------------*/

#include <stdio.h>
#include "Blinky.h"
#include "LPC17xx.h"                       
#include "GLCD.h"
#include "LED.h"
//#include "Board_ADC.h" 
#include "KBD.h"

#define __FI        1                      /* Font index 16x24               */
#define __USE_LCD   0										/* Uncomment to use the LCD */

//ITM Stimulus Port definitions for printf //////////////////
#define ITM_Port8(n)    (*((volatile unsigned char *)(0xE0000000+4*n)))
#define ITM_Port16(n)   (*((volatile unsigned short*)(0xE0000000+4*n)))
#define ITM_Port32(n)   (*((volatile unsigned long *)(0xE0000000+4*n)))

#define DEMCR           (*((volatile unsigned long *)(0xE000EDFC)))
#define TRCENA          0x01000000

struct __FILE { int handle;  };
FILE __stdout;
FILE __stdin;

int fputc(int ch, FILE *f) {
  if (DEMCR & TRCENA) {
    while (ITM_Port32(0) == 0);
    ITM_Port8(0) = ch;
  }
  return(ch);
}


char text[10];
int option;

static volatile uint16_t AD_dbg;

uint16_t ADC_last;                      // Last converted value
/* Import external variables from IRQ.c file                                  */
extern uint8_t  clock_ms;

void menuSelect(){
	#ifdef  __USE_LCD						
		GLCD_SetBackColor(Blue);
		GLCD_SetTextColor(Yellow);
		GLCD_DisplayString(0, 0, __FI, "     COE718 Demo    ");
		GLCD_SetTextColor(White);
		GLCD_DisplayString(1, 0, __FI, "       Project      ");
		GLCD_DisplayString(2, 0, __FI, "     Trevor Nice    ");
		GLCD_SetBackColor(White);
		GLCD_SetTextColor(Blue);
		GLCD_DisplayString(4, 0, __FI, "1. Gallery    ");
		GLCD_DisplayString(5, 0, __FI, "2. MP3 Player ");
		GLCD_DisplayString(6, 0, __FI, "3. Game Center");					
		GLCD_DisplayString(7, 0, __FI, "4. Trivia     ");
	#endif
	switch(option){
						case 1:
							#ifdef  __USE_LCD
								GLCD_SetBackColor(Blue);
								GLCD_SetTextColor(White);
								GLCD_DisplayString(4, 0, __FI, "1. Gallery    ");
								GLCD_SetBackColor(White);
								GLCD_SetTextColor(Blue);
								GLCD_DisplayString(5, 0, __FI, "2. MP3 Player ");
								GLCD_DisplayString(6, 0, __FI, "3. Game Center");
								GLCD_DisplayString(7, 0, __FI, "4. Trivia     ");
							#endif
						break;
						case 2:
							#ifdef  __USE_LCD
								GLCD_DisplayString(4, 0, __FI, "1. Gallery    ");
								GLCD_SetBackColor(Blue);
								GLCD_SetTextColor(White);
								GLCD_DisplayString(5, 0, __FI, "2. MP3 Player ");
								GLCD_SetBackColor(White);
								GLCD_SetTextColor(Blue);
								GLCD_DisplayString(6, 0, __FI, "3. Game Center");
								GLCD_DisplayString(7, 0, __FI, "4. Trivia     ");
							#endif						
						break;
						case 3:
							#ifdef  __USE_LCD
								GLCD_DisplayString(4, 0, __FI, "1. Gallery    ");
								GLCD_DisplayString(5, 0, __FI, "2. MP3 Player ");
								GLCD_SetBackColor(Blue);
								GLCD_SetTextColor(White);
								GLCD_DisplayString(6, 0, __FI, "3. Game Center");
								GLCD_SetBackColor(White);
								GLCD_SetTextColor(Blue);
								GLCD_DisplayString(7, 0, __FI, "4. Trivia     ");
							#endif
						break;
						case 4:
							#ifdef  __USE_LCD
								GLCD_DisplayString(4, 0, __FI, "1. Gallery    ");
								GLCD_DisplayString(5, 0, __FI, "2. MP3 Player ");
								GLCD_DisplayString(6, 0, __FI, "3. Game Center");
								GLCD_SetBackColor(Blue);
								GLCD_SetTextColor(White);
								GLCD_DisplayString(7, 0, __FI, "4. Trivia     ");
								GLCD_SetBackColor(White);
								GLCD_SetTextColor(Blue);
							#endif
						break;
					}
}

extern void gallery();
extern void mp3_m();
extern void games();
extern void trivia();

/*----------------------------------------------------------------------------
  Main Program
 *----------------------------------------------------------------------------*/
int main (void) {
	uint32_t input;
	int i;
	option = 1;

  //LED_Init();                                /* LED Initialization            */
  //ADC_Initialize();                                /* ADC Initialization            */
	KBD_Init(); //Initialize the joystick

  GLCD_Init();                               /* Initialize graphical LCD (if enabled */

  GLCD_Clear(White);
	menuSelect();

  SystemCoreClockUpdate();
  //SysTick_Config(SystemCoreClock/100);       /* Generate interrupt each 10 ms */

	//Code that runs the main menu
  while (1) {                                /* Loop forever                  */
		//get Joystick input
		input = get_button();
		//if there is a non zero joystick input
		if(input!=0){
				//assign output based on input
				switch(input){
					case KBD_SELECT:
						//On the main menu select does nothing
					break;
					
					case KBD_UP:
						if(option == 1){
							option = 4;
							menuSelect();
						}
						else{
							option--;
							menuSelect();
						}
					break;
					
					case KBD_LEFT:
						//On the main menu left does nothing
					break;
					
					case KBD_DOWN:
						if(option == 4){
							option = 1;
							menuSelect();
						}
						else{
							option++;
							menuSelect();
						}
					break;
					
					case KBD_RIGHT:
					//Go to the method for whichever option is selected
					switch(option){
						case 1:
							gallery();
							option = 1;
							menuSelect();
						break;
						case 2:
							mp3_m();
							option = 2;
							menuSelect();
						break;
						case 3:
							games();
							option = 3;
							menuSelect();
						break;
						case 4:
							trivia();
							option = 4;
							menuSelect();
						break;
					}
					break;
				}
		}
		//busy-wait loop to reduce joystick sensitivity
		for(i = 0; i <1000000; i++){
			
		}
  }
}
