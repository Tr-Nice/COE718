#include <stdio.h>
#include "Blinky.h"
#include "LPC17xx.h"                       
#include "GLCD.h"
#include "LED.h"
//#include "Board_ADC.h" 
#include "KBD.h"
#include <string.h>

#define __FI        1                      /* Font index 16x24               */
#define __USE_LCD   0										/* Uncomment to use the LCD */

//ITM Stimulus Port definitions for printf //////////////////
#define ITM_Port8(n)    (*((volatile unsigned char *)(0xE0000000+4*n)))
#define ITM_Port16(n)   (*((volatile unsigned short*)(0xE0000000+4*n)))
#define ITM_Port32(n)   (*((volatile unsigned long *)(0xE0000000+4*n)))

#define DEMCR           (*((volatile unsigned long *)(0xE000EDFC)))
#define TRCENA          0x01000000

const char *questions[] = {"Who was Canada's first Prime Minister?", "Which city is the capital of Canada?", "What is the term for a word that is the same spelled forwards and backwords?", "What colour is red and blue combined?", "What are the names of the five Great Lakes?", "Which city is the capital of Japan?", "What country is the Chernobyl power plant located in?"};
const char *answers[] = {"Sir John A. McDonald", "Ottawa", "Palindrome", "Purple", "Superior, Michigan, Huron, Erie and Ontario", "Tokyo", "Ukraine"};
char ttext[21];
int tnum;
int numQuestions = 7;
uint32_t Qinput;

void printTrivia(int q){
	int i,j;
	GLCD_SetBackColor(White);
	GLCD_SetTextColor(Blue);
	i = 3;
	for(j = 0; j <= strlen(questions[q]); j+=20){
		memcpy(ttext, questions[q]+j, 20);
		ttext[20] = '\0';
		GLCD_DisplayString(i, 0, __FI, (unsigned char*)ttext);
		i++;
	}
}
void printAnswer(int q){
	int i,j;
	GLCD_SetBackColor(White);
	GLCD_SetTextColor(Blue);
	i = 3;
	for(j = 0; j <= strlen(answers[q]); j+=20){
		memcpy(ttext, answers[q]+j, 20);
		ttext[20] = '\0';
		GLCD_DisplayString(i, 0, __FI, (unsigned char*)ttext);
		i++;
	}
}

void printHeader(){
		GLCD_Clear(White);
		GLCD_SetBackColor(Blue);
		GLCD_SetTextColor(Yellow);
		GLCD_DisplayString(0, 0, __FI, "       Trivia        ");
}

void trivia(){
		int i;
		printHeader();
		tnum = 0;	
		printTrivia(tnum);
		
	
	  while (1) {                                /* Loop forever                  */
		//get Joystick input
		Qinput = get_button();
		//sprintf(text, "0x%4X", input);
		//if there is a non zero joystick input
		if(Qinput!=0){
				//assign output based on input
				switch(Qinput){
					case KBD_SELECT:
						//does nothing
					break;
					
					case KBD_UP:
						if(tnum !=0){
							tnum--;
						}
						else{
							tnum=numQuestions-1;
						}
						GLCD_Clear(White);
						printHeader();
						printTrivia(tnum);
					break;
					
					case KBD_LEFT:
						GLCD_Clear(White);
						return;
					break;
					
					case KBD_DOWN:
						if(tnum !=numQuestions-1){
							tnum++;
						}
						else{
							tnum=0;
						}
						GLCD_Clear(White);
						printHeader();
						printTrivia(tnum);
					break;
					
					case KBD_RIGHT:
						GLCD_Clear(White);
						printHeader();
						printAnswer(tnum);
					break;
				}
		}
		//busy-wait loop to reduce joystick sensitivity
		for(i = 0; i <1000000; i++){
			
		}
  }
}